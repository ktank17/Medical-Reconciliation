# CS603Project
![Dbtable_Medicaldetails](DbImages/PatientMedication.png)
![Dbtable_Patienttable](DbImages/Patienttable.png)
